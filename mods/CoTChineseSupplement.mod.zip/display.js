(() => {
  const terms = {"Academic buildings": "学术建筑", "Alpha Xi Alpha House": "ΑΞΑ会宅", "Apartment": "公寓", "Apartment 1BR": "一居室公寓", "Apartment 2BR": "两居室公寓", "Apartment 3BR": "三居室公寓", "Art": "艺术", "Available": "可用", "Back": "返回", "Back Hall": "后厅", "Backyard": "后院", "Bancroft Lane": "班克罗夫特巷", "Bancroft Suites": "班克罗夫特套房", "BangCoffee": "邦咖啡", "Basement": "地下室", "Bathroom": "浴室", "Bedroom": "卧室", "Blodgett Gym": "布洛杰特体育馆", "Blodgett Gymnasium": "布洛杰特体育馆", "Bold Cuts": "风尚剪艺", "Bootlicker": "靴奴", "By the Back Door": "后门附近", "Calendar": "日历", "Campus": "校园", "Campus Clinic": "学院诊所", "Campus recreation & services": "校园娱乐与服务", "Cancel": "取消", "Chamberlain Hall": "钱伯兰大厅", "Chicory Hall": "玉兰菊宿舍楼", "Clinic": "诊所", "Close": "关闭", "Computer Lab": "机房", "Confirm": "确认", "Contacts": "联系人", "Date Palm Apartments": "椰枣公寓", "Date Palm Street": "枣椰街", "Decor": "装饰", "Delta Delta Rho House": "ΔΔΡ姐妹会", "Deposit": "押金", "Dr. Cuttlefish": "墨鱼博士", "Emerson Building": "埃默森大楼", "Emerson Road": "埃默森路", "Empty room": "空房间", "Entertainment room": "娱乐室", "Esports Changing Room": "电竞更衣室", "Export": "导出", "Fadogia Street": "法多基亚街", "FamilyJewels": "传家珍宝", "Fighting Elks": "热血麋鹿", "Forecast": "天气预报", "Four Bedroom Suite": "四居室套房", "Furniture": "家具", "Gen Ed": "通识教育", "Ginseng Street": "人参街", "Greek Houses": "希腊活动中心", "Gym Pool": "健身房游泳池", "HELP": "帮助", "Hallowell Building": "哈洛韦尔大楼", "Hallowell Road": "哈洛韦尔路", "Hanna Road North": "汉纳北路", "Hanna Road South": "汉纳南路", "Helleborine Hall Lounge": "火烧兰宿舍楼休息室", "Helleborine-Trillium Quad": "火烧兰-延龄草方庭", "Hoplite Cinema": "霍普利特电影院", "Horned Toad Tattoo": "角蜥纹艺", "Howling Jigoku": "嚎叫地狱", "Import": "导入", "In a Bedroom": "卧室", "Inventory": "物品栏", "JT Ult": "约特超商", "Kitchen": "厨房", "Large Rural House": "大型乡间住宅", "Laundry Room": "洗衣房", "Lickety Splits Bowling Alley": "快闪小站保龄球馆", "Living room": "客厅", "Load": "读取", "Longfellow Road": "朗费罗路", "Lounge": "休息室", "Mail Center": "邮件中心", "Main Hall": "大厅", "Main Room": "主厅", "Master Blaster Arcade": "爆裂大师", "Media Production Lab": "媒体制作工作室", "Media Producton Lab": "媒体制作工作室", "Medium Rural House": "中型乡间住宅", "Men's Locker Room": "男更衣室", "Men's Room": "男厕", "Messages": "消息", "Mezzanine": "夹层", "Mr. Gable's": "盖博先生", "Next": "下一步", "No one": "无人", "Nobbly Barns": "诺布利书屋", "Nutmeg Street": "豆蔻街", "OPTIONS": "选项", "One Bedroom Suite": "一居室套房", "Other": "其他", "Owned": "已拥有", "Pembleton Way": "彭布尔顿大道", "Photo Studio": "摄影工作室", "Prescott Road": "普雷斯科特路", "Previous": "上一步", "Public Restroom": "公共厕所", "QuickieBurger": "捷堡", "Reception": "前台", "Recovery Room": "康复室", "Reminders": "提醒", "Rent": "租金", "Residence Halls": "宿舍楼", "Residence halls": "宿舍楼", "Restroom": "洗手间", "Rival House": "敌对社团会宅", "River Peninsula": "河边半岛", "River Rat": "河鼠", "Riverside": "河滨镇", "Riverside Community Center": "河畔社区中心", "Riverside Community Thrift": "河滨社区中心旧货店", "Riverside Motel": "河滨汽车旅馆房间", "Riverside Motel Front Office": "河滨汽车旅馆前台", "Riverside Municipal Center": "河滨市政中心", "Roommates": "室友", "SAVE": "存档", "SUPPORT": "支持", "Saffron Street": "番红花街", "Save": "存档", "Science/Compsci": "科学/计算机科学", "Settings": "设置", "Showers": "淋浴间", "Sigma Omicron Theta House": "ΣΟΘ会宅", "Small Rural House": "小型乡间住宅", "Smith Library": "史密斯图书馆", "Specter Jester": "幽灵小丑", "SportsDrip": "运动风尚", "Steve's Movie Center and Romantic Supermart": "史蒂夫电影中心与浪漫超市", "Storage": "储物", "Student Parking": "学生停车场", "Suite": "套房", "Suites": "套房", "Summit Market": "顶峰市场", "The Bus": "巴士", "The Greenhouse": "温室", "The River Rat": "河鼠", "The Selena Benton Observatory": "赛琳娜·本顿天文台", "Thoreau Building": "梭罗大楼", "Thoreau Road": "梭罗路", "To Town": "前往城镇", "To town": "通往城镇", "Two Bedroom Suite": "两居室套房", "Unavailable": "不可用", "Unisex Locker Room": "男女通用更衣室", "University Mall": "大学生中心", "Upstairs": "楼上", "Walk-in closet": "步入式衣帽间", "Women's Locker Room": "女更衣室", "Women's Room": "女厕", "X-cross": "X形架", "Yohimbe Street": "约希姆比街", "Your Bedroom": "你的卧室", "Your Best Friend's Dorm": "你最好朋友的房间", "Your Dorm": "你的宿舍", "Zeta Kappa Xi House": "ΖΚΞ会宅", "alley": "小巷", "apartments": "公寓楼", "area": "区域", "back room": "后室", "bathroom": "浴室", "bathroom stall": "卫生间隔间", "bed": "床", "bedroom": "卧室", "black leather paddle": "黑色皮拍", "box": "盒子", "bus": "巴士", "bush": "灌木", "business park": "商务园", "car": "车", "chair": "椅子", "classroom": "教室", "computer desk": "电脑桌", "computer lab": "计算机实验室", "couch": "硬沙发", "counter": "柜台", "desk": "书桌", "desk chair": "书桌椅子", "door": "门", "dorm room": "宿舍房间", "dressing room": "化妆间", "dryer": "烘干机", "entertainment room": "娱乐室", "faded black leather flogger": "褪色的黑色皮散鞭", "floor": "地面", "fridge": "柜台", "futon": "蒲团", "garden": "花园", "glass wall": "玻璃墙", "greenhouse": "温室", "ground": "地面", "guest bedroom": "客卧", "gym": "健身房", "hospital room": "医院房间", "industrial park": "工业园", "kitchen": "厨房", "laundry room": "洗衣房", "library": "图书馆", "library basement": "图书馆地下室", "living room": "客厅", "lobby": "大厅", "locker room": "更衣室", "lounge": "休息室", "master bedroom": "主卧", "meeting room": "会议室", "motel room": "汽车旅馆房间", "no one": "无人", "observatory": "天文台", "office": "办公室", "parkinglot": "停车场", "pavement": "路面", "pool": "水池", "porn studio": "色情工作室", "quad": "方庭", "residences": "住宅区", "restaurant": "餐厅", "room": "房间", "second bedroom": "次卧", "shelf": "架子", "shower room": "淋浴间", "shower stall": "淋浴间隔间", "side of a building": "建筑侧面", "sidewalk": "人行道", "sofa": "沙发", "store": "商店", "street": "街道", "study": "书房", "table": "桌子", "the lockers": "柜子", "thrift shop": "旧货店", "toilet": "厕所", "tree": "树", "tub": "浴缸", "tub seat": "浴缸座位", "tub top": "浴缸顶部", "violet silicone whip": "紫色硅胶鞭", "wall": "墙", "washing machine": "洗衣机", "window": "窗户"};
  const escape = value => value.replace(/[.*+?^${}()|[\]\\]/g, '\\$&');
  const pattern = new RegExp('(^|[^A-Za-z0-9_])(' + Object.keys(terms)
    .sort((a, b) => b.length - a.length).map(escape).join('|') + ')(?=$|[^A-Za-z0-9_])', 'g');
  function text(value) {
    return typeof value === 'string'
      ? value.replace(pattern, (_, prefix, term) => prefix + terms[term]) : value;
  }
  function unitLabel(key) {
    if (typeof key !== 'string') return '';
    if (/^Suite \d+$/.test(key)) return key.slice(6) + ' 号套房';
    if (/^Apartment \d+$/.test(key)) return key.slice(10) + ' 号公寓';
    const address = /^(\d+) (?:Saffron Street|番红花街)$/.exec(key);
    if (address) return '番红花街 ' + address[1] + ' 号';
    return text(key);
  }
  setup.CoTChinese = {text, unitLabel, version: '1.0.0', termCount: Object.keys(terms).length};

  // Only presentation data: keep housing keys, room IDs and save variables intact.
  if (setup.Housing) {
    for (const name of ['Bancroft Suites', 'Date Palm Apartments']) {
      if (setup.Housing.buildings[name]) setup.Housing.buildings[name].cn_name = terms[name];
    }
    setup.Housing.get_room_label = function(plan, roomID) {
      const here = State.variables.housing;
      const saved = here?.plan === plan
        ? State.variables.pchousing?.[here.key]?.rooms?.[roomID] : null;
      // Player-assigned labels always take precedence.
      if (saved?.label) return saved.label;
      const info = this.plans[plan]?.rooms?.[roomID];
      const roomClass = saved?.class || info?.class;
      if (saved?.class) return text(this.roomClasses[roomClass]?.cn_name || roomClass);
      return text(info?.label || info?.cn_name || this.roomClasses[roomClass]?.cn_name || roomClass || roomID || '房间');
    };
  }
  if (setup.dormstuff?.['fabric sofa']?.name === '%color sofa') {
    setup.dormstuff['fabric sofa'].name = '%color沙发';
  }

  const roots = '#passages, #ui-dialog, #ui-bar';
  const skip = 'script, style, pre, code, textarea, input, select, option, [contenteditable], .error-view, .debug';
  function translateNode(node) {
    const parent = node.parentElement;
    if (!parent || !parent.closest(roots) || parent.closest(skip)) return;
    // Unit identifiers are formatted for display, never renamed in game state.
    const units = node.data.replace(/(^|[^A-Za-z0-9_])(Suite \d+|Apartment \d+)(?=$|[^A-Za-z0-9_])/g,
      (_, prefix, key) => prefix + unitLabel(key));
    const translated = text(units);
    if (translated !== node.data) node.data = translated;
  }
  function walk(root) {
    if (root.nodeType === Node.TEXT_NODE) { translateNode(root); return; }
    if (root.nodeType !== Node.ELEMENT_NODE) return;
    const walker = document.createTreeWalker(root, NodeFilter.SHOW_TEXT);
    let node;
    while ((node = walker.nextNode())) translateNode(node);
  }
  $(document).one(':storyready', () => {
    for (const root of document.querySelectorAll(roots)) walk(root);
    const observer = new MutationObserver(records => {
      for (const record of records) {
        if (record.type === 'characterData') translateNode(record.target);
        else for (const added of record.addedNodes) walk(added);
      }
    });
    observer.observe(document.body, {subtree: true, childList: true, characterData: true});
  });
})();
