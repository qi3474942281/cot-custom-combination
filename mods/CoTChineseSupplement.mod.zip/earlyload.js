(() => {
  const fixes = [{"passage": "HousingRentNew", "from": "<<= setup.Housing.get_room_label(V.pchousing[_hkey].plan, V.pchousing[_hkey].rooms[0]) || _hkey>>", "to": "<<= setup.CoTChinese.unitLabel(_hkey)>>"}, {"passage": "HousingRentNew", "from": "<<= (setup.Housing.buildings[$housingbuilding] && setup.Housing.buildings[$housingbuilding].cn_name) || $housingbuilding>>", "to": "<<= setup.CoTChinese.text($housingbuilding)>>"}, {"passage": "HousingRoom", "from": "setup.and(setup.render_names(_owners), \"no one\")", "to": "setup.and(setup.render_names(_owners), \"无人\")"}, {"passage": "ShopWidgets", "from": "<<link _shopitem.label ", "to": "<<link `setup.CoTChinese.shopLabel(_shopitem)` "}, {"passage": "ShopItem", "from": "<<= $shopitem.label>>", "to": "<<= setup.CoTChinese.shopLabel($shopitem)>>"}, {"passage": "ShopWidgets", "from": "new RegExp(RegExp.escape(V.shopsearch), \"i\").test(catitem.label) ||", "to": "new RegExp(RegExp.escape(V.shopsearch), \"i\").test(setup.CoTChinese.shopLabel(catitem)) || new RegExp(RegExp.escape(V.shopsearch), \"i\").test(catitem.label) ||"}, {"passage": "ShopWidgets", "from": "_categories[0].name.toUpperFirst()", "to": "setup.CoTChinese.shopText(_categories[0].name.toUpperFirst())"}, {"passage": "ShopWidgets", "from": "_categories[_i].name.toUpperFirst()", "to": "setup.CoTChinese.shopText(_categories[_i].name.toUpperFirst())"}, {"passage": "ShopMenu", "from": "<<= _shopinfo.description>>", "to": "<<= setup.CoTChinese.shopText(_shopinfo.description)>>"}, {"passage": "ShopItem", "from": "<<= _obj.description>>", "to": "<<= setup.CoTChinese.shopText(_obj.description)>>"}, {"passage": "ShopItem", "from": "<<= _info.description>>", "to": "<<= setup.CoTChinese.shopText(_info.description)>>"}, {"passage": "ShopWidgets", "from": "<<= _obj.description>>", "to": "<<= setup.CoTChinese.shopText(_obj.description)>>"}, {"passage": "ShopWidgets", "from": "<<= _shopitem.description>>", "to": "<<= setup.CoTChinese.shopText(_shopitem.description)>>"}, {"passage": "ShopWidgets", "from": "<<= _foodobj.description>>", "to": "<<= setup.CoTChinese.shopText(_foodobj.description)>>"}, {"passage": "ShopWidgets", "from": "<<= setup.dormstuff[_shopitem.item].description>>", "to": "<<= setup.CoTChinese.shopText(setup.dormstuff[_shopitem.item].description)>>"}, {"passage": "SimpleShopMenu", "from": "<<link _shopitem.label ", "to": "<<link `setup.CoTChinese.shopLabel(_shopitem)` "}, {"passage": "SimpleShopMenu", "from": "<<= _shopitem.label>>", "to": "<<= setup.CoTChinese.shopText(_shopitem.label)>>"}, {"passage": "ShopWidgets", "from": "setup.capitalize_each(_sub_opt)", "to": "setup.CoTChinese.shopOption($shopitem, _sub_name, _sub_opt)"}, {"passage": "ShopItem", "from": "document.getElementById(\"span-\"+sub).innerText=setup.capitalize_each(opt);", "to": "document.getElementById(\"span-\"+sub).innerText=setup.CoTChinese.shopOption(V.shopitem, sub, opt);"}];
  const manager = window.modSC2DataManager;
  const cache = manager.getSC2DataInfoAfterPatch();
  const patched = cache.cloneSC2DataInfo();
  const applied = [];
  for (const fix of fixes) {
    const passage = patched.passageDataItems.items.find(p => p.name === fix.passage);
    if (!passage || !passage.content.includes(fix.from)) {
      console.warn('[CoTChineseSupplement] missing expected display fragment', fix.passage);
      continue;
    }
    passage.content = passage.content.split(fix.from).join(fix.to);
    applied.push(fix.passage);
  }
  if (applied.length) {
    patched.passageDataItems.fillMap();
    manager.getModUtils().replaceFollowSC2DataInfo(patched, cache);
  }
  console.log('[CoTChineseSupplement] patched display fragments', applied);
})();
