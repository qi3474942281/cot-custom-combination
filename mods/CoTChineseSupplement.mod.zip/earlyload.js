(() => {
  const fixes = [{"passage": "HousingRentNew", "from": "<<= setup.Housing.get_room_label(V.pchousing[_hkey].plan, V.pchousing[_hkey].rooms[0]) || _hkey>>", "to": "<<= setup.CoTChinese.unitLabel(_hkey)>>"}, {"passage": "HousingRentNew", "from": "<<= (setup.Housing.buildings[$housingbuilding] && setup.Housing.buildings[$housingbuilding].cn_name) || $housingbuilding>>", "to": "<<= setup.CoTChinese.text($housingbuilding)>>"}, {"passage": "HousingRoom", "from": "setup.and(setup.render_names(_owners), \"no one\")", "to": "setup.and(setup.render_names(_owners), \"无人\")"}];
  const manager = window.modSC2DataManager;
  const cache = manager.getSC2DataInfoAfterPatch();
  const patched = cache.cloneSC2DataInfo();
  const applied = [];
  for (const fix of fixes) {
    const passage = patched.passageDataItems.items.find(p => p.name === fix.passage);
    if (!passage || !passage.content.includes(fix.from)) {
      console.warn('[CoTChineseSupplement] missing expected display fragment', fix.passage);
      continue;
    }
    passage.content = passage.content.split(fix.from).join(fix.to);
    applied.push(fix.passage);
  }
  if (applied.length) {
    patched.passageDataItems.fillMap();
    manager.getModUtils().replaceFollowSC2DataInfo(patched, cache);
  }
  console.log('[CoTChineseSupplement] patched display fragments', applied);
})();
