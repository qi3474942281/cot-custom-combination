
# Mes' NPC visualization mod for Course of Temptation
# version 1.0.6.2

Many thanks to my best friend Susan who saved me a lot of times from the brink of giving up!

Thanks to the help from River, Eudemonism00, BlackTeaPie, miyako, pmm!! I really can't make it without help from them!!

If you find any bugs please DM me to help me improve the mod.

# What this mod do?
    This mod displays NPC images in the People tab and Person tab, helping to visualize the NPCs.

# How to use this mod?
    Unzip this mod, merge it with the original game folder, then run the mod's HTML file.

# Can this mod be added or removed from existing saves?
    It should be safe to add or remove this mod in existing saves, but since there's not enough tests, I still recommend you to use it in a new save or backup your old save before overwrite it.