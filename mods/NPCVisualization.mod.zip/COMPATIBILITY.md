# CoT 0.8.0h compatibility

Original portraits and artwork: Maenoko / NPC-Visualization-Mod, mobile v1.0.6.2.
https://github.com/Maenoko/NPC-Visualization-Mod/releases/download/v1.0.6.3/Modloader_Mobile_Mes.NPC.visualization.mod.1.0.6.2.for.v.0.6.1c.zip

Adaptation: current DisplayNPC and SocialWidgets insertion points; player portraits in Character and StoryCaption; scoped responsive layers; guards for uncovered upper bodies; fallback art for new clothing/hair missing from the original pack.
Original README and all artwork are retained.
